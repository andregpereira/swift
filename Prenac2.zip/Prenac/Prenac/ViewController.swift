//
//  ViewController.swift
//  Prenac
//
//  Created by Usuário Convidado on 17/08/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lblDados: UILabel!
    var strTexto:String=""

    override func viewDidLoad() {
        super.viewDidLoad()
        lblDados.text = strTexto
    }


}

