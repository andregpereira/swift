//
//  ViewController.swift
//  Exemplo Json Nutella
//
//  Created by Usuário Convidado on 21/09/23.
//

import UIKit

class ViewController: UIViewController {
    
    var comic:Comic!=nil
    
    @IBOutlet weak var id: UILabel!
    @IBOutlet weak var data: UILabel!
    @IBOutlet weak var titulo: UILabel!
    @IBOutlet weak var minhaImagem: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func exibir(_ sender: Any) {
        
    }
    
    
    func loadComic(){
        let jsonURLString = "https://xkcd.com/info.0.json"
        let url = URL(string: jsonURLString)
        
        URLSession.shared.dataTask(with: url!) { data, response, error in
            //fazer na próxima aula o do catch para trazer os dados
            
            
        }
        .resume()
    }
    
}

